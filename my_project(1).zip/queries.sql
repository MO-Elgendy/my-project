/* Q1 - What is the number of movies in each family-friendly category?*/ 
WITH 
updated_cats AS 
	(SELECT fc.film_id, c.name
    FROM film_category fc
    JOIN category c
    ON c.category_id = fc.category_id), 
updated_qrental AS 
    (SELECT DISTINCT f.title AS film_title, uc.name, f.rental_duration, ntile(4) OVER 			
     (PARTITION BY f.rental_duration) AS standard_quartile
    FROM film f
    JOIN updated_cats uc
    ON uc.film_id = f.film_id
    WHERE uc.name IN ('Family', 'Children', 'Music', 'Animation', 'Comedy','Games')
    ORDER BY 4,3)

SELECT name, count(*)
FROM updated_qrental
GROUP BY 1
ORDER BY 2;


/*  Q2 - What is the number of rental orders for each store per month?*/
SELECT Date_TRUNC('month', r.rental_date) Rental_month, i.store_id, COUNT(*) Count_rentals
FROM rental r
LEFT JOIN inventory i
ON i.inventory_id = r.inventory_id
GROUP BY 1,2
ORDER BY 3 DESC;



/* Q3 - What is the number total number of rentals for the top 10 customers based on the highest rental orders per month?*/

WITH 
top_10 AS 
	(SELECT c.customer_id, CONCAT (c.first_name, ' ', c.last_name) fullname, COUNT(*) pay_countpermon, SUM(p.amount)
	FROM payment p
	JOIN customer c
	ON p.customer_id = c.customer_id
	GROUP BY 1,2
	ORDER BY 3 DESC, 2
	LIMIT 10)

SELECT fullname, SUM(pay_countpermon)
FROM (SELECT DATE_TRUNC('month', p.payment_date) pay_mon, t.fullname, COUNT(DATE_TRUNC('month', p.payment_date)) pay_countpermon, SUM(p.amount)
FROM payment p
JOIN top_10 t
ON p.customer_id = t.customer_id
GROUP BY 1,2                                       
ORDER BY 2,3 DESC) sub
GROUP BY 1
ORDER BY 2 DESC;



/*  Q4 - Who are the customers with highest difference in rental orders from a month to another?*/
WITH
top_10 AS
	(SELECT c.customer_id, CONCAT (c.first_name, ' ', c.last_name) fullname, COUNT(*) pay_countpermon, SUM(p.amount) total_rents
	FROM payment p
	JOIN customer c
	ON p.customer_id = c.customer_id
	GROUP BY 1,2
	ORDER BY 3 DESC, 2
	LIMIT 10)

SELECT DATE_TRUNC('month', p.payment_date) pay_mon, t.fullname, COUNT(DATE_TRUNC('month', p.payment_date)) pay_countpermon, SUM(p.amount), SUM(p.amount) - LAG(SUM(p.amount)) OVER (PARTITION BY t.fullname ORDER BY DATE_TRUNC('month', p.payment_date)) difference
FROM payment p
JOIN top_10 t
ON p.customer_id = t.customer_id
GROUP BY 1,2;   


/* Query 5 - query used for third insight */
WITH top10 AS (SELECT c.customer_id, SUM(p.amount) AS total_payments
FROM customer c
JOIN payment p
ON p.customer_id = c.customer_id
GROUP BY c.customer_id
ORDER BY total_payments DESC
LIMIT 10)

SELECT DATE_TRUNC('month', payment_date) AS pay_mon, (first_name || ' ' || last_name) AS full_name, COUNT(p.amount) AS pay_countpermon, SUM(p.amount) AS pay_amount
FROM top10
JOIN customer c
ON top10.customer_id = c.customer_id
JOIN payment p
ON p.customer_id = c.customer_id
WHERE payment_date >= '2007-01-01' AND payment_date < '2008-01-01'
GROUP BY 1, 2
ORDER BY 2, 1

/* Query 6 - query used for fourth insight */
WITH top10 AS (SELECT c.customer_id, SUM(p.amount) AS total_payments
FROM customer c
JOIN payment p
ON p.customer_id = c.customer_id
GROUP BY c.customer_id
ORDER BY total_payments DESC
LIMIT 10),

t2 AS (SELECT DATE_TRUNC('month', payment_date) AS pay_mon, (first_name || ' ' || last_name) AS full_name, 
SUM(p.amount) AS pay_amount
FROM top10
JOIN customer c
ON top10.customer_id = c.customer_id
JOIN payment p
ON p.customer_id = c.customer_id
WHERE payment_date >= '2007-01-01' AND payment_date < '2008-01-01'
GROUP BY 1, 2)

SELECT *, 
LAG(t2.pay_amount) OVER (PARTITION BY full_name ORDER BY t2.pay_amount) AS lag, 
(pay_amount - COALESCE(LAG(t2.pay_amount) OVER (PARTITION BY full_name ORDER BY t2.pay_mon), 0)) AS diff
FROM t2
ORDER BY diff DESC